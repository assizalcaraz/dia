# Documentación de API Endpoints

**Versión**: v0.1  
**Base URL**: `http://localhost:8000/api` (desarrollo)  
**Formato**: JSON  
**Método**: Todos los endpoints son GET (read-only)

---

## Resumen

La API de `/dia` es **read-only** y expone datos de sesiones, eventos y métricas almacenados en archivos NDJSON. No requiere autenticación en v0.1 (solo desarrollo local).

---

## Endpoints

### 1. `GET /api/sessions/`

Lista todas las sesiones registradas.

**Parámetros**: Ninguno

**Respuesta**:

```json
{
  "sessions": [
    {
      "day_id": "2026-01-18",
      "session_id": "S01",
      "intent": "Implementar feature X",
      "dod": "Feature funcionando y tests pasando",
      "mode": "it",
      "start_ts": "2026-01-18T10:00:00-03:00",
      "end_ts": "2026-01-18T14:30:00-03:00",
      "result": "closed",
      "repo": {
        "path": "/ruta/al/repo",
        "vcs": "git",
        "branch": "main",
        "start_sha": "abc123",
        "end_sha": "def456",
        "dirty": false
      },
      "project": {
        "tag": "mi-proyecto",
        "area": "it",
        "context": ""
      }
    }
  ]
}
```

**Orden**: Sesiones ordenadas por `start_ts` descendente (más recientes primero).

**Notas**:
- Sesiones sin `end_ts` están activas (no cerradas).
- `result` puede ser `"closed"` o `null` (si no se cerró).

**Ejemplo**:

```bash
curl http://localhost:8000/api/sessions/
```

---

### 2. `GET /api/sessions/current/`

Retorna la sesión activa actual (si existe).

**Parámetros**: Ninguno

**Respuesta** (sesión activa):

```json
{
  "session": {
    "day_id": "2026-01-18",
    "session_id": "S01",
    "intent": "Implementar feature X",
    "dod": "Feature funcionando y tests pasando",
    "mode": "it",
    "start_ts": "2026-01-18T10:00:00-03:00",
    "end_ts": null,
    "result": null,
    "repo": {...},
    "project": {...}
  }
}
```

**Respuesta** (sin sesión activa):

```json
{
  "session": null
}
```

**Notas**:
- Retorna la sesión más reciente sin `end_ts`.
- Si todas las sesiones están cerradas, retorna `null`.

**Ejemplo**:

```bash
curl http://localhost:8000/api/sessions/current/
```

---

### 3. `GET /api/events/recent/`

Retorna eventos recientes (últimos N eventos).

**Parámetros de Query**:

- `limit` (opcional, default: `20`): Número máximo de eventos a retornar.

**Respuesta**:

```json
{
  "events": [
    {
      "event_id": "evt_01J2QA0KJ8F1N8Y7D4B7H3C2XY",
      "ts": "2026-01-18T10:00:00-03:00",
      "type": "SessionStarted",
      "session": {
        "day_id": "2026-01-18",
        "session_id": "S01"
      },
      "actor": {...},
      "project": {...},
      "repo": {...},
      "payload": {...},
      "links": [...]
    }
  ]
}
```

**Orden**: Eventos ordenados por timestamp descendente (más recientes primero).

**Notas**:
- Retorna los últimos `limit` eventos del archivo `events.ndjson`.
- El formato es el mismo que el NDJSON (1 evento = 1 objeto JSON).

**Ejemplo**:

```bash
curl http://localhost:8000/api/events/recent/?limit=10
```

---

### 4. `GET /api/metrics/`

Retorna métricas básicas del sistema.

**Parámetros**: Ninguno

**Respuesta**:

```json
{
  "total_sessions": 15,
  "commit_suggestions": 8,
  "total_events": 142
}
```

**Campos**:

- `total_sessions`: Número total de sesiones (iniciadas, cerradas o no).
- `commit_suggestions`: Número de eventos `CommitSuggestionIssued`.
- `total_events`: Número total de eventos en `events.ndjson`.

**Ejemplo**:

```bash
curl http://localhost:8000/api/metrics/
```

---

### 5. `GET /api/summaries/`

Retorna resúmenes diarios generados por `dia close-day`.

**Parámetros**: Ninguno

**Respuesta**:

```json
{
  "summaries": [
    {
      "event_id": "evt_...",
      "ts": "2026-01-18T18:00:00-03:00",
      "type": "DailySummaryGenerated",
      "session": {
        "day_id": "2026-01-18",
        "session_id": null
      },
      "payload": {
        "objective": "Implementar autenticación OAuth2",
        "sessions": 2,
        "closed_sessions": 2,
        "total_events": 15
      }
    }
  ]
}
```

**Orden**: Resúmenes ordenados por timestamp descendente (más recientes primero).

**Notas**:
- Retorna eventos `DailySummaryGenerated` de `daily_summaries.ndjson`.
- Estos son los resúmenes que la UI muestra en la zona indeleble.

**Ejemplo**:

```bash
curl http://localhost:8000/api/summaries/
```

---

### 6. `GET /api/jornada/<day_id>/`

Retorna el contenido completo de la bitácora de jornada para un día específico.

**Parámetros de Path**:

- `day_id` (requerido): Fecha en formato `YYYY-MM-DD` (ej: `2026-01-18`).

**Respuesta** (éxito):

```json
{
  "day_id": "2026-01-18",
  "content": "# Jornada 2026-01-18\n\n## 1. Intención del día (manual)\n..."
}
```

**Respuesta** (error 404):

```json
{
  "error": "Jornada no encontrada"
}
```

**Notas**:
- Retorna el contenido completo del archivo Markdown de la bitácora.
- El contenido incluye secciones manuales (1 y 2) y automáticas (3+).

**Ejemplo**:

```bash
curl http://localhost:8000/api/jornada/2026-01-18/
```

---

### 7. `GET /api/captures/recent/`

Retorna capturas recientes (errores/logs capturados con `dia cap`).

**Parámetros de Query**:

- `limit` (opcional, default: `20`): Número máximo de capturas a retornar.

**Respuesta**:

```json
{
  "captures": [
    {
      "event_id": "evt_...",
      "type": "CaptureCreated",
      "ts": "2026-01-18T15:15:00-03:00",
      "session": {
        "day_id": "2026-01-18",
        "session_id": "S01"
      },
      "payload": {
        "kind": "error",
        "title": "deploy staging falla",
        "error_hash": "a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
        "artifact_ref": "artifacts/captures/2026-01-18/S01/cap_a1b2c3d4e5f6.txt"
      },
      "links": [
        {
          "kind": "artifact",
          "ref": "artifacts/captures/2026-01-18/S01/cap_a1b2c3d4e5f6.txt"
        }
      ]
    }
  ]
}
```

**Tipos de eventos**:
- `CaptureCreated`: Captura nueva.
- `CaptureReoccurred`: Captura repetida (mismo hash).

**Orden**: Capturas ordenadas por timestamp descendente (más recientes primero).

**Ejemplo**:

```bash
curl http://localhost:8000/api/captures/recent/?limit=10
```

---

### 8. `GET /api/captures/errors/open/`

Retorna lista de errores sin fix (último `CaptureCreated` sin `FixLinked` por sesión).

**Parámetros**: Ninguno

**Respuesta**:

```json
{
  "errors": [
    {
      "event_id": "evt_...",
      "ts": "2026-01-18T15:15:00-03:00",
      "session": {
        "day_id": "2026-01-18",
        "session_id": "S01"
      },
      "title": "deploy staging falla",
      "error_hash": "a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
      "artifact_ref": "artifacts/captures/2026-01-18/S01/cap_a1b2c3d4e5f6.txt",
      "links": [...]
    }
  ]
}
```

**Orden**: Errores ordenados por timestamp descendente (más recientes primero).

**Notas**:
- Retorna solo el último error sin fix por sesión.
- Si una sesión tiene múltiples errores sin fix, solo aparece el más reciente.
- Estos son los errores que la UI muestra en la zona viva.

**Ejemplo**:

```bash
curl http://localhost:8000/api/captures/errors/open/
```

---

## Estructura de Datos

### Session Object

```typescript
{
  day_id: string;           // "2026-01-18"
  session_id: string;      // "S01"
  intent: string;          // Intención de la sesión
  dod: string;             // Definición de Hecho
  mode: string;            // "it" | "maker" | "study" | "life"
  start_ts: string | null; // ISO 8601 timestamp
  end_ts: string | null;   // ISO 8601 timestamp (null si activa)
  result: string | null;   // "closed" | null
  repo: RepoObject | null;
  project: ProjectObject;
}
```

### Repo Object

```typescript
{
  path: string;            // Ruta absoluta del repo
  vcs: string;             // "git"
  branch: string;          // Rama actual
  start_sha: string | null; // SHA inicial de la sesión
  end_sha: string | null;   // SHA final de la sesión
  dirty: boolean;          // Si hay cambios sin commit
}
```

### Project Object

```typescript
{
  tag: string;             // Nombre del proyecto
  area: string;            // "it" | "maker" | "study" | "life"
  context: string;         // Contexto adicional
}
```

### Event Object

Ver [Estructura NDJSON de eventos](../specs/NDJSON.md) para formato completo.

---

## Códigos de Error

### 404 Not Found

**Cuándo**: 
- `GET /api/jornada/<day_id>/` cuando la bitácora no existe

**Respuesta**:
```json
{
  "error": "Jornada no encontrada"
}
```

### 500 Internal Server Error

**Cuándo**: 
- Error al leer archivos NDJSON
- Permisos insuficientes
- Archivos corruptos

**Respuesta**: Error estándar de Django (formato HTML o JSON según headers).

---

## Ejemplos de Uso

### Ejemplo 1: Obtener Sesión Activa

```bash
curl http://localhost:8000/api/sessions/current/
```

**Uso en JavaScript**:

```javascript
const response = await fetch('http://localhost:8000/api/sessions/current/');
const data = await response.json();
if (data.session) {
  console.log('Sesión activa:', data.session.session_id);
} else {
  console.log('No hay sesión activa');
}
```

### Ejemplo 2: Listar Errores Abiertos

```bash
curl http://localhost:8000/api/captures/errors/open/
```

**Uso en JavaScript**:

```javascript
const response = await fetch('http://localhost:8000/api/captures/errors/open/');
const data = await response.json();
data.errors.forEach(error => {
  console.log(`Error: ${error.title} (${error.error_hash.substring(0, 8)})`);
});
```

### Ejemplo 3: Obtener Resúmenes Diarios

```bash
curl http://localhost:8000/api/summaries/
```

**Uso en JavaScript**:

```javascript
const response = await fetch('http://localhost:8000/api/summaries/');
const data = await response.json();
data.summaries.forEach(summary => {
  console.log(`${summary.session.day_id}: ${summary.payload.sessions} sesiones`);
});
```

---

## Integración con UI

La UI de Svelte consume estos endpoints para mostrar:

- **Zona indeleble**: Resúmenes diarios (`/api/summaries/`)
- **Zona viva**: Sesión activa (`/api/sessions/current/`), errores abiertos (`/api/captures/errors/open/`)
- **Historial**: Sesiones (`/api/sessions/`), eventos recientes (`/api/events/recent/`)

**Auto-refresh**: La UI actualiza cada 5 segundos.

---

## Notas de Implementación

- Todos los endpoints son **read-only** (GET).
- No hay autenticación en v0.1 (solo desarrollo local).
- Los datos se leen directamente de archivos NDJSON en `data/`.
- No hay caché: cada request lee los archivos desde disco.
- El formato de respuesta es JSON estándar.

---

## Referencias

- [Estructura NDJSON de eventos](../specs/NDJSON.md)
- [Guía de `dia start`](../guides/dia-start.md)
- [Guía de `dia cap`](../guides/dia-cap.md)
- [Resumen de diseño](../overview/RESUMEN_DISENO_DIA.md)
