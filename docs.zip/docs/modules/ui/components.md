# Documentación de Componentes UI

**Versión**: v0.1  
**Estado**: Pendiente de documentación detallada

---

## Componentes Principales

### `App.svelte`

Componente principal de la UI que muestra:
- **Zona indeleble**: Historial de sesiones y resúmenes diarios
- **Zona viva**: Sesión activa, checklist, eventos recientes, errores abiertos

**Auto-refresh**: Cada 5 segundos

---

## Integración con API

La UI consume los siguientes endpoints:

- `GET /api/sessions/current/` — Sesión activa
- `GET /api/summaries/` — Resúmenes diarios (zona indeleble)
- `GET /api/captures/errors/open/` — Errores abiertos (zona viva)

---

## Notas

Esta documentación está pendiente de completar. Ver código fuente en `ui/src/App.svelte` para detalles de implementación.

---

## Referencias

- [Documentación de API](api/endpoints.md)
- [Guías de comandos](../../guides/)
