# Tutorial completo — /dia v0.1

**Objetivo**: Aprender a usar todas las herramientas de `/dia` para establecer un ciclo de trabajo estructurado con síntesis orientada a objetivo.

---

## Requisitos previos

- Contenedores `server` y `ui` corriendo (Docker)
- Un repo Git local para trabajar
- Acceso a `data/` dentro del monorepo
- Entorno virtual activo: `source envdia/bin/activate`

---

## Parte 1: Instalación y verificación

### 1.1 Instalar la CLI local

```bash
cd /Users/joseassizalcarazbaxter/Developer/dia/cli
pip install -e .
```

**Notas**:
- El punto final (`.`) es obligatorio
- Si `pip` falla, actualizar: `python3 -m pip install --upgrade pip setuptools wheel`
- Si cambias empaquetado: `dia update`
- Si solo cambias `.py`, no hace falta reinstalar

### 1.2 Levantar servicios (Docker)

```bash
make up
```

**Verificar**:
- UI: `http://localhost:5173` (debe mostrar zonas indeleble/viva)
- API: `http://localhost:8000/api/sessions/` (debe retornar JSON)

---

## Parte 2: Flujo completo de trabajo

### 2.1 Iniciar sesión (`dia start`)

**Desde el repo donde vas a trabajar**:

```bash
cd /ruta/al/repo
dia start --data-root /ruta/al/monorepo/data --area it
```

**Qué sucede**:
1. Confirma nombre del proyecto (nombre del directorio)
2. Solicita **intención** (1 frase): "Implementar feature X"
3. Solicita **DoD** (Definición de Hecho): "Feature funcionando y tests pasando"
4. Solicita **modo** (default `it`): Enter o especificar

**Qué se genera**:
- ✅ Bitácora de jornada: `data/bitacora/YYYY-MM-DD.md` (si no existe, se crea)
- ✅ Sección automática con inicio de sesión
- ✅ Eventos `SessionStarted` y `RepoBaselineCaptured` en `events.ndjson`
- ✅ Archivo `.cursorrules` en el repo (recordatorio para Cursor)
- ✅ UI muestra sesión activa en zona viva

**Estructura de bitácora creada**:

```markdown
# Jornada YYYY-MM-DD

## 1. Intención del día (manual)
- Objetivo principal:
- Definición de Hecho (DoD):
- Restricciones / contexto:

## 2. Notas humanas (manual)
- ideas
- dudas
- decisiones
- observaciones subjetivas relevantes

---

## 3. Registro automático (NO EDITAR)
(append-only, escrito por /dia)

### Sesión S01
- start: 2026-01-17T10:00:00-03:00
- intent: Implementar feature X
- dod: Feature funcionando y tests pasando
- mode: it
- repo: /ruta/al/repo
- branch: main
- start_sha: abc123
- end: (pendiente)
- commits: (pendiente)
- eventos:

#### Eventos
- 2026-01-17T10:00:00-03:00 — SessionStarted
```

**Importante**: Las secciones 1 y 2 son **editables manualmente**. `/dia` solo escribe en la sección 3 en adelante.

### 2.2 Editar intención del día (opcional)

**Antes de trabajar**, edita la bitácora para definir tu objetivo:

```bash
# Abrir bitácora del día
code data/bitacora/2026-01-17.md  # o tu editor preferido
```

**Completar sección 1**:

```markdown
## 1. Intención del día (manual)
- Objetivo principal: Implementar autenticación OAuth2
- Definición de Hecho (DoD): Login funcional, tests pasando, docs actualizados
- Restricciones / contexto: No romper autenticación existente
```

**Completar sección 2** (durante el trabajo):

```markdown
## 2. Notas humanas (manual)
- Decisión: usar librería X en lugar de Y (más simple)
- Duda: ¿validar tokens en cada request o cachear?
- Observación: el código legacy tiene acoplamiento fuerte
```

**Regla**: Solo edita las secciones 1 y 2. La sección 3 es append-only.

### 2.3 Trabajar normalmente

Trabaja en tu repo como siempre. `/dia` no interfiere.

**Durante el trabajo**, puedes agregar notas en la sección 2 de la bitácora.

### 2.4 Capturar errores (`dia cap`)

**Ver guía completa**: [Guía de `dia cap`](../guides/dia-cap.md)

**Cuando encuentres un error o log importante**:

**Opción A: Por pipe** (cuando un comando falla):
```bash
comando_que_falla 2>&1 | dia cap --kind error --title "deploy staging" --data-root /ruta/al/monorepo/data --area it
```

**Opción B: Pegado manual**:
```bash
dia cap --kind error --title "deploy staging" --stdin --data-root /ruta/al/monorepo/data --area it
# Pegar contenido del error, luego Ctrl-D
```

**Qué sucede**:
- Lee el contenido desde stdin (pipe o manual)
- Calcula hash SHA256 del contenido
- Guarda artifact en `data/artifacts/captures/YYYY-MM-DD/Sxx/cap_<id>.txt`
- Genera `.meta.json` con metadatos (repo, commit, sesión)
- Detecta si el error ya existía (mismo hash) → genera `CaptureReoccurred`
- Si es nuevo → genera `CaptureCreated`
- Registra evento en `events.ndjson`

**Ejemplo de salida**:
```bash
Captura creada: cap_a1b2c3d4e5f6
Artifact: data/artifacts/captures/2026-01-18/S01/cap_a1b2c3d4e5f6.txt
Meta: data/artifacts/captures/2026-01-18/S01/cap_a1b2c3d4e5f6.meta.json
```

**Si el error se repite**:
```bash
Error repetido detectado (hash: a1b2c3d4...)
```

**Parámetros**:
- `--kind` (required): `error` | `log`
- `--title` (required): descripción breve del error/log
- `--repo` (optional): path del repo (default: cwd actual)
- `--stdin` (flag): forzar lectura desde stdin (default: auto-detecta pipe)

**Importante**: Requiere sesión activa (`dia start` ejecutado previamente).

### 2.5 Linkear fix a error (`dia fix`)

**Ver guía completa**: [Guía de `dia fix`](../guides/dia-fix.md)

**Después de arreglar un error capturado**:

```bash
dia fix --title "corregir variable de entorno faltante" --data-root /ruta/al/monorepo/data --area it
```

**Qué sucede**:
- Busca el último error sin fix de la sesión actual
- Obtiene el commit actual (HEAD) o marca como working tree
- Genera evento `FixLinked` con referencia al error
- Si no hay commit aún, sugiere usar `dia pre-feat`

**Ejemplo de salida**:
```bash
Fix linkeado a error: a1b2c3d4...
Error event_id: evt_01J2QA0KJ8F1N8Y7D4B7H3C2XY
Fix commit: d4c3b2a1
```

**Si el fix está en working tree**:
```bash
Fix en working tree (aun sin commit)
Ejecuta 'dia pre-feat' para sugerir commit
```

**Parámetros**:
- `--from` (optional): `capture_id` específico (default: último sin fix)
- `--title` (required): descripción del fix
- `--repo` (optional): path del repo (default: cwd actual)

**Trazabilidad**: El evento `FixLinked` conecta el error (`CaptureCreated`) con el commit del fix, permitiendo auditoría completa.

### 2.6 Checkpoint pre-feat (`dia pre-feat`)

**Ver guía completa**: [Guía de `dia pre-feat`](../guides/dia-pre-feat.md)

**Antes de hacer un commit importante**:

```bash
dia pre-feat --data-root /ruta/al/monorepo/data --area it
```

**Qué sucede**:
- Analiza archivos cambiados
- **Si hay error activo sin fix**: sugiere mensaje tipo `fix: <título> [dia] [#sesion Sxx] [#error <hash>]`
- **Si no hay error activo**: sugiere mensaje normal según tipo de cambio
- Registra evento `CommitSuggestionIssued` (con referencia a error si aplica)

**Ejemplo de salida (con error activo)**:
```bash
git-commit-cursor -m "🦾 fix: corregir variable de entorno faltante [dia] [#sesion S01] [#error a1b2c3d4]"
```

**Ejemplo de salida (sin error activo)**:
```bash
git-commit-cursor -m "🦾 feat: agregar autenticación OAuth2 [#sesion S01]"
```

**Qué hacer**:
1. Copia el comando sugerido
2. Ejecútalo (o modifícalo si necesitas)
3. El commit queda identificado como de Cursor/IA (🦾 + autoría específica)
4. Si había referencia a error, el commit queda vinculado al error

**Nota**: `dia pre-feat` **no ejecuta** el commit, solo lo sugiere.

### 2.7 Cerrar sesión (`dia end`)

**Ver guía completa**: [Guía de `dia end`](../guides/dia-end.md)

**Al terminar de trabajar en la sesión**:

```bash
dia end --data-root /ruta/al/monorepo/data --area it
```

**Qué sucede**:
- Calcula diff de la sesión (start_sha → end_sha)
- Detecta archivos sospechosos (`docs/scratch/`, tests fuera de `tests/`)
- Actualiza bitácora de jornada (sección automática)
- Genera archivos legacy: `CIERRE_Sxx.md` y `LIMPIEZA_Sxx.md`
- Registra eventos: `RepoDiffComputed`, `CleanupTaskGenerated`, `SessionEnded`

**Ejemplo de actualización en bitácora**:

```markdown
### Sesión S01
- start: 2026-01-17T10:00:00-03:00
- intent: Implementar feature X
- dod: Feature funcionando y tests pasando
- mode: it
- repo: /ruta/al/repo
- branch: main
- start_sha: abc123
- end: 2026-01-17T14:30:00-03:00
- commits: 3
- archivos_tocados: 12
- 2026-01-17T14:30:00-03:00 — SessionEnded
```

**Archivos generados**:
- `data/bitacora/YYYY-MM-DD/CIERRE_S01.md` (resumen de sesión)
- `data/bitacora/YYYY-MM-DD/LIMPIEZA_S01.md` (tareas de limpieza)

### 2.8 Cerrar jornada (`dia close-day`)

**Ver guía completa**: [Guía de `dia close-day`](../guides/dia-close-day.md)

**Al final del día** (después de cerrar todas las sesiones):

```bash
dia close-day --data-root /ruta/al/monorepo/data --area it
```

**Qué sucede**:
- Lee todos los eventos del día
- Analiza sesiones iniciadas vs cerradas
- Extrae objetivo del día (sección 1 de bitácora)
- Genera **resumen del día** (sección 5 de bitácora)
- Crea **análisis comparativo vs objetivo** (`analysis/YYYY-MM-DD_vs_objetivo.md`)
- Registra evento `DailySummaryGenerated` en `daily_summaries.ndjson`

**Ejemplo de resumen generado** (sección 5):

```markdown
## 5. Resumen del día (generado)

- Qué se intentó: 2 sesiones iniciadas
- Qué se logró realmente: 2 sesiones cerradas, 15 eventos registrados
- Qué no se logró y por qué: Todas las sesiones cerradas
- Desvíos detectados:
- Sin desvíos detectados
```

**Análisis vs objetivo generado** (`analysis/2026-01-17_vs_objetivo.md`):

```markdown
# Análisis 2026-01-17 vs Objetivo

## Objetivo declarado
Implementar autenticación OAuth2

## Plan esperado
Login funcional, tests pasando, docs actualizados

## Resultado real
2 sesiones cerradas, 15 eventos registrados

## Brechas
- Sin brechas significativas

## Impacto
2/2 sesiones completadas

## Ajustes sugeridos
- Sin ajustes sugeridos
```

**Importante**: `dia close-day` es el paso que convierte eventos en **síntesis útil**. Sin este paso, solo tienes datos crudos.

---

## Parte 3: Convenciones y herramientas

### 3.1 Convención de commits

**Sistema de identificación**:

- **Commits de Cursor/IA**: 
  - Usar `git-commit-cursor` (sugerido por `dia pre-feat`)
  - Autoría: `Cursor Assistant <cursor@dia.local>`
  - Prefijo 🦾 al INICIO del mensaje
  - Formato: `🦾 tipo: mensaje [#sesion Sxx]`

- **Commits manuales**:
  - Usar `git -M` (o commit normal)
  - Tu autoría normal
  - Sin emoji
  - Formato: `tipo: mensaje`

**Ejemplos**:

```bash
# Commit de Cursor/IA (sugerido por dia pre-feat)
git-commit-cursor -m "🦾 feat: agregar autenticación OAuth2 [#sesion S01]"

# Commit manual tuyo
git -M "fix: corregir validación de email"
```

**Por qué**: Identifica rápidamente en `git log` qué commits fueron hechos por Cursor/IA vs manualmente.

### 3.2 Recordatorios automáticos para Cursor

**Al iniciar sesión**: `dia start` genera automáticamente `.cursorrules` en el repo activo.

**Contenido**:
- Convención de commits (🦾 al inicio, usar `git-commit-cursor`)
- Autoría identificable
- Workflow /dia

**Actualización**: Se regenera cada vez que ejecutas `dia start`.

**Manual**: También puedes generarlo manualmente:

```bash
python3 -m dia_cli.cursor_reminder > .cursorrules
```

### 3.3 Usar la UI para visualizar

**Zona indeleble** (historial):
- Muestra **resúmenes diarios** (no eventos crudos)
- Estado de objetivos
- Tendencias (sesiones cerradas vs abiertas)

**Zona viva** (día actual):
- Sesión activa (si hay una)
- Estado del día basado en resúmenes
- Checklist diario
- **Errores abiertos** (últimos 5 errores sin fix)

**Actualización**: Auto-refresh cada 5 segundos.

**Principio**: La UI muestra **síntesis**, no datos crudos. Si no hay resúmenes (no ejecutaste `dia close-day`), verás mensajes indicando que debes generarlos.

---

## Parte 4: Estructura de archivos generados

### 4.1 Bitácora de jornada (`bitacora/YYYY-MM-DD.md`)

**Estructura**:

```
# Jornada YYYY-MM-DD

## 1. Intención del día (manual) ← EDITABLE
- Objetivo principal:
- Definición de Hecho (DoD):
- Restricciones / contexto:

## 2. Notas humanas (manual) ← EDITABLE
- ideas
- dudas
- decisiones

---

## 3. Registro automático (NO EDITAR) ← APPEND-ONLY
### Sesión S01
- start: ...
- eventos: ...

## 4. Incrementales automáticos ← APPEND-ONLY
- checkpoints
- sugerencias

## 5. Resumen del día (generado) ← GENERADO POR close-day
- Qué se intentó: ...
- Qué se logró: ...
```

**Regla dura**: `/dia` solo escribe en secciones 3, 4 y 5. Las secciones 1 y 2 son exclusivamente humanas.

### 4.2 Índices NDJSON

**`data/index/events.ndjson`**:
- Todos los eventos (append-only)
- Formato: 1 JSON por línea
- Tipos: `SessionStarted`, `SessionEnded`, `CommitSuggestionIssued`, etc.

**`data/index/daily_summaries.ndjson`**:
- Resúmenes diarios generados por `close-day`
- Formato: 1 JSON por línea
- Tipo: `DailySummaryGenerated`

**`data/index/sessions.ndjson`**:
- Índice de sesiones (legacy, mantenido por compatibilidad)

### 4.3 Análisis y artefactos

**`data/analysis/YYYY-MM-DD_vs_objetivo.md`**:
- Análisis comparativo generado por `close-day`
- Compara objetivo vs resultado real
- Identifica brechas y sugiere ajustes

**`data/artifacts/`**:
- Diffs de repositorio
- Logs y estadísticas
- **Capturas de errores**: `artifacts/captures/YYYY-MM-DD/Sxx/cap_<id>.txt` y `.meta.json`
- Referenciados desde eventos NDJSON

---

## Parte 5: Flujo recomendado

### Flujo diario completo

1. **Inicio de jornada**:
   ```bash
   dia start --data-root /ruta/al/monorepo/data --area it
   ```

2. **Editar intención** (opcional pero recomendado):
   - Abrir `data/bitacora/YYYY-MM-DD.md`
   - Completar sección 1 (objetivo, DoD, restricciones)

3. **Trabajar**:
   - Trabajar normalmente en el repo
   - Agregar notas en sección 2 si es necesario

4. **Capturar errores** (cuando ocurren):
   ```bash
   comando_que_falla 2>&1 | dia cap --kind error --title "descripción" --data-root /ruta/al/monorepo/data --area it
   ```

5. **Arreglar error y linkear fix**:
   ```bash
   # ... arreglar el error ...
   dia fix --title "descripción del fix" --data-root /ruta/al/monorepo/data --area it
   ```

6. **Checkpoint** (antes de commits importantes):
   ```bash
   dia pre-feat --data-root /ruta/al/monorepo/data --area it
   # Copiar y ejecutar comando sugerido (incluirá referencia a error si aplica)
   ```

7. **Cerrar sesión** (al terminar trabajo de la sesión):
   ```bash
   dia end --data-root /ruta/al/monorepo/data --area it
   ```

8. **Cerrar jornada** (al final del día):
   ```bash
   dia close-day --data-root /ruta/al/monorepo/data --area it
   ```

7. **Revisar síntesis**:
   - Leer sección 5 de bitácora (resumen del día)
   - Leer análisis vs objetivo
   - Revisar UI para ver resúmenes

### Flujo con múltiples sesiones

Puedes tener múltiples sesiones en un mismo día:

```bash
# Sesión 1 (mañana)
dia start --data-root /ruta/al/monorepo/data --area it
# ... trabajar ...
dia end --data-root /ruta/al/monorepo/data --area it

# Sesión 2 (tarde)
dia start --data-root /ruta/al/monorepo/data --area it
# ... trabajar ...
dia end --data-root /ruta/al/monorepo/data --area it

# Cerrar jornada (una sola vez al final del día)
dia close-day --data-root /ruta/al/monorepo/data --area it
```

**Nota**: `dia close-day` analiza **todas las sesiones del día** y genera un resumen consolidado.

---

## Parte 6: Principios y reglas

### Principio rector

> **Los eventos son materia prima. Los resúmenes son el producto.**

`/dia` no es útil si solo genera listas de eventos. Su valor está en la **síntesis orientada a objetivo** que produce `dia close-day`.

### Reglas duras

1. **Bitácora**: `/dia` solo puede escribir en secciones 3, 4 y 5. Las secciones 1 y 2 son exclusivamente humanas.

2. **Append-only**: Los archivos NDJSON y las secciones automáticas de bitácora son append-only. No se reescriben.

3. **No ejecuta**: `/dia` no ejecuta commits, pushes ni cambios en repos. Solo sugiere y registra.

4. **Cierre obligatorio**: Para obtener síntesis útil, debes ejecutar `dia close-day` al final del día.

### Buenas prácticas

- **Completar intención**: Edita la sección 1 de la bitácora para que `close-day` pueda generar análisis útil.
- **Cerrar sesiones**: Siempre ejecuta `dia end` antes de `dia close-day`.
- **Revisar resúmenes**: Lee la sección 5 y el análisis vs objetivo para aprender del día.
- **Usar UI**: La UI muestra síntesis, no eventos crudos. Úsala para visión general.

---

## Parte 7: Solución de problemas

### Problema: "No hay eventos registrados para YYYY-MM-DD"

**Causa**: No ejecutaste `dia start` ese día.

**Solución**: Ejecuta `dia start` para iniciar una sesión.

### Problema: "No existe bitácora para YYYY-MM-DD"

**Causa**: No ejecutaste `dia start` ese día, o la bitácora no se creó.

**Solución**: Ejecuta `dia start` primero. La bitácora se crea automáticamente.

### Problema: UI no muestra resúmenes

**Causa**: No ejecutaste `dia close-day`.

**Solución**: Ejecuta `dia close-day` para generar resúmenes. La UI consume `daily_summaries.ndjson`.

### Problema: Análisis vs objetivo dice "No especificado"

**Causa**: No completaste la sección 1 de la bitácora (objetivo principal).

**Solución**: Edita `data/bitacora/YYYY-MM-DD.md` y completa la sección 1 antes de ejecutar `dia close-day`.

### Problema: Sesión no aparece en UI

**Causa**: La sesión no está activa o no se registró correctamente.

**Solución**: 
1. Verifica que ejecutaste `dia start`
2. Verifica que `events.ndjson` tiene el evento `SessionStarted`
3. Verifica que no ejecutaste `dia end` (que cierra la sesión)

---

## Parte 8: Checklist de validación

Después de un día completo de trabajo, verifica:

- ✅ Bitácora de jornada existe: `data/bitacora/YYYY-MM-DD.md`
- ✅ Sección 1 completada (objetivo, DoD)
- ✅ Sección 3 tiene registros de sesiones
- ✅ Sección 5 tiene resumen del día (generado por `close-day`)
- ✅ Análisis vs objetivo existe: `data/analysis/YYYY-MM-DD_vs_objetivo.md`
- ✅ `daily_summaries.ndjson` tiene entrada del día
- ✅ UI muestra resúmenes en zona indeleble
- ✅ Todos los eventos están en `events.ndjson`

---

## Conclusión

`/dia` te ayuda a:

1. **Estructurar el trabajo** (sesiones con intención clara)
2. **Registrar evidencia** (eventos inmutables)
3. **Generar síntesis** (resúmenes orientados a objetivo)
4. **Aprender del día** (análisis comparativo vs objetivo)

**El paso más importante**: Ejecutar `dia close-day` al final del día. Sin este paso, solo tienes datos crudos. Con este paso, tienes síntesis útil para tomar decisiones.

---

**Próximos pasos**: Una vez que tengas 2-4 semanas de datos consistentes, podrás usar los índices NDJSON para análisis avanzado (grafos, patrones, mentor).
