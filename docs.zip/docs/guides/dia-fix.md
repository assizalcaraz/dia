# Guía: `dia fix`

**Comando**: `dia fix`  
**Versión**: v0.1  
**Propósito**: Linkea un fix aplicado a un error capturado previamente, estableciendo trazabilidad error → fix → commit.

---

## Sintaxis

```bash
dia fix --title "<descripción>" [--from <capture_id>] [--data-root <ruta>] [--repo <ruta>] [--area <area>] [--context <contexto>] [--actor <actor>] [--user-type <tipo>] [--role <rol>] [--client <cliente>]
```

---

## Parámetros

### Parámetros Comunes

Ver [Guía de `dia start`](dia-start.md#parámetros-comunes-todos-los-comandos) para parámetros comunes (`--data-root`, `--area`, `--context`, `--actor`, `--user-type`, `--role`, `--client`).

### Parámetros Específicos

- `--title <descripción>` (requerido): Descripción breve del fix aplicado.
- `--from <capture_id>` (opcional): ID específico del error a linkear. Si no se especifica, usa el último error sin fix de la sesión actual.
- `--repo <ruta>` (opcional): Ruta del repositorio Git. Si no se especifica, usa el directorio actual (`cwd`).

---

## Comportamiento

### 1. Verificación de Sesión Activa

- Busca una sesión activa para el repositorio actual (o especificado).
- Si no hay sesión activa, muestra error y termina con código de salida 1.

### 2. Búsqueda del Error a Linkear

**Si se especifica `--from <capture_id>`**:
- Busca el error específico por `capture_id` en los eventos.
- Si no encuentra, muestra error y termina con código de salida 1.

**Si no se especifica `--from`**:
- Busca el último `CaptureCreated` sin `FixLinked` asociado en la sesión actual.
- Si no encuentra, muestra error y termina con código de salida 1.

### 3. Obtención del Estado del Repo

- Obtiene la rama actual.
- Obtiene el SHA del HEAD (commit actual).
  - Si no hay commits, `fix_sha` será `None` (working tree).

### 4. Generación del Evento

Registra evento `FixLinked` en `data/index/events.ndjson`:

```json
{
  "event_id": "evt_...",
  "ts": "2026-01-18T15:30:00-03:00",
  "type": "FixLinked",
  "session": {
    "day_id": "2026-01-18",
    "session_id": "S01"
  },
  "repo": {
    "path": "/ruta/al/repo",
    "branch": "main",
    "end_sha": "d4c3b2a1"
  },
  "payload": {
    "error_event_id": "evt_01J2QAG7K9M3N5P8Q2R4S6T1U3V",
    "error_hash": "a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
    "fix_sha": "d4c3b2a1",
    "title": "corregir variable de entorno faltante"
  }
}
```

### 5. Salida

Muestra información del fix linkeado:

- Hash del error (primeros 8 caracteres)
- Event ID del error
- SHA del commit del fix (o indica working tree)

---

## Archivos Generados

### Eventos NDJSON

**Ubicación**: `data/index/events.ndjson`

**Evento generado**: `FixLinked`

---

## Ejemplos de Uso

### Ejemplo 1: Linkear Fix al Último Error

```bash
# 1. Capturar error
comando_que_falla 2>&1 | dia cap --kind error --title "deploy staging falla" --data-root /ruta/data --area it

# 2. Arreglar el error
# ... editar código ...

# 3. Linkear fix
dia fix --title "corregir variable de entorno faltante" --data-root /ruta/data --area it
```

**Salida**:
```
Fix linkeado a error: a1b2c3d4...
Error event_id: evt_01J2QAG7K9M3N5P8Q2R4S6T1U3V
Fix commit: d4c3b2a1
```

### Ejemplo 2: Linkear Fix a Error Específico

```bash
# Múltiples errores capturados
error1 2>&1 | dia cap --kind error --title "error 1" --data-root /ruta/data --area it
error2 2>&1 | dia cap --kind error --title "error 2" --data-root /ruta/data --area it

# Arreglar error 2 específicamente
dia fix --from cap_a1b2c3d4e5f6 --title "fix error 2" --data-root /ruta/data --area it
```

**Salida**:
```
Fix linkeado a error: b2c3d4e5...
Error event_id: evt_...
Fix commit: e9f8g7h6
```

### Ejemplo 3: Fix en Working Tree (Sin Commit)

```bash
# Arreglar error
# ... editar código (sin commit aún) ...

# Linkear fix
dia fix --title "corregir timeout" --data-root /ruta/data --area it
```

**Salida**:
```
Fix linkeado a error: a1b2c3d4...
Error event_id: evt_...
Fix en working tree (aun sin commit)
Ejecuta 'dia pre-feat' para sugerir commit
```

---

## Casos de Uso

### Caso 1: Flujo Completo Error → Fix → Commit

**Escenario**: Capturar error, arreglarlo, linkear fix y hacer commit.

```bash
# 1. Error ocurre
comando_que_falla 2>&1 | dia cap --kind error --title "deploy staging falla" --data-root /ruta/data --area it

# 2. Analizar error
# Revisar artifact: data/artifacts/captures/YYYY-MM-DD/Sxx/cap_<id>.txt

# 3. Arreglar error
# ... editar código ...

# 4. Linkear fix
dia fix --title "corregir variable de entorno faltante" --data-root /ruta/data --area it

# 5. Commit (con referencia a error)
dia pre-feat --data-root /ruta/data --area it
# Salida: git-commit-cursor -m "🦾 fix: deploy staging falla [dia] [#sesion S01] [#error a1b2c3d4]"

# 6. Ejecutar commit
git-commit-cursor -m "🦾 fix: deploy staging falla [dia] [#sesion S01] [#error a1b2c3d4]"
```

**Resultado**: Trazabilidad completa: error → fix → commit.

### Caso 2: Múltiples Errores, Fixes Específicos

**Escenario**: Capturar múltiples errores y arreglarlos uno por uno.

```bash
# Error 1
error1 2>&1 | dia cap --kind error --title "error 1" --data-root /ruta/data --area it

# Error 2
error2 2>&1 | dia cap --kind error --title "error 2" --data-root /ruta/data --area it

# Arreglar error 1
# ... editar código ...
dia fix --from cap_<id_error1> --title "fix error 1" --data-root /ruta/data --area it

# Arreglar error 2
# ... editar código ...
dia fix --from cap_<id_error2> --title "fix error 2" --data-root /ruta/data --area it
```

**Resultado**: Cada error linkeado a su fix específico.

### Caso 3: Fix Antes de Commit

**Escenario**: Linkear fix cuando el código está en working tree (sin commit aún).

```bash
# Capturar error
error 2>&1 | dia cap --kind error --title "error" --data-root /ruta/data --area it

# Arreglar (sin commit)
# ... editar código ...

# Linkear fix
dia fix --title "fix temporal" --data-root /ruta/data --area it
# Salida: "Fix en working tree (aun sin commit)"

# Luego hacer commit
dia pre-feat --data-root /ruta/data --area it
# Ejecutar commit sugerido
```

**Resultado**: Fix linkeado, pero `fix_sha` es `None` hasta hacer commit.

---

## Integración con Otros Comandos

### Flujo con Captura de Errores

```bash
# 1. Iniciar sesión
dia start --data-root /ruta/data --area it

# 2. Error ocurre → capturar
comando_que_falla 2>&1 | dia cap --kind error --title "descripción" --data-root /ruta/data --area it

# 3. Arreglar error
# ... editar código ...

# 4. Linkear fix
dia fix --title "descripción del fix" --data-root /ruta/data --area it

# 5. Commit (opcional, pero recomendado)
dia pre-feat --data-root /ruta/data --area it
# Ejecutar comando sugerido

# 6. Cerrar sesión
dia end --data-root /ruta/data --area it
```

### Dependencias

- **Requiere**: 
  - Sesión activa (`dia start` ejecutado previamente)
  - Error capturado con `dia cap` (o especificar `--from`)
- **Usa**: 
  - Información de sesión activa
  - Eventos `CaptureCreated` para encontrar errores
- **Genera**: 
  - Evento `FixLinked` que conecta error con fix
  - Trazabilidad que `dia pre-feat` puede usar

---

## Trazabilidad Error → Fix → Commit

El sistema permite rastrear el ciclo completo:

1. **Error ocurre** → `CaptureCreated` (con `error_hash` y `repo.head_sha`)
2. **Error se repite** → `CaptureReoccurred` (referencia al `original_event_id`)
3. **Fix aplicado** → `FixLinked` (con `error_event_id`, `error_hash`, `fix_sha`)
4. **Commit sugerido** → `CommitSuggestionIssued` (con `error_ref` si hay error activo)

**Preguntas que puedes responder**:

- ¿Qué commit introdujo el error? → `repo.head_sha` del `CaptureCreated`
- ¿Qué commit lo arregló? → `fix_sha` del `FixLinked`
- ¿Reapareció o era nuevo? → Presencia de `CaptureReoccurred`

---

## Troubleshooting

### Error: "No hay sesion activa para este repo"

**Causa**: No se ejecutó `dia start` previamente.

**Solución**: 
```bash
dia start --data-root /ruta/data --area it
```

### Error: "No hay errores sin fix en esta sesion"

**Causa**: 
- No se capturó ningún error con `dia cap`
- Todos los errores ya fueron linkeados con `dia fix`

**Solución**: 
- Capturar error primero: `dia cap --kind error --title "..." --data-root /ruta/data --area it`
- O especificar error específico: `dia fix --from cap_<id> --title "..." --data-root /ruta/data --area it`

### Error: "Capture <id> no encontrado"

**Causa**: El `capture_id` especificado con `--from` no existe.

**Solución**: 
- Verificar el ID del error (está en la salida de `dia cap`)
- O usar sin `--from` para linkear al último error sin fix

---

## Notas de Implementación

- El comando **no ejecuta** el commit. Solo linkea el fix al error.
- Si el fix está en working tree (sin commit), `fix_sha` será `None`.
- El comando busca el **último** error sin fix si no se especifica `--from`.
- El evento `FixLinked` permite trazabilidad completa error → fix → commit.

---

## Referencias

- [Guía de `dia cap`](dia-cap.md)
- [Guía de `dia pre-feat`](dia-pre-feat.md)
- [Guía de `dia start`](dia-start.md)
- [Tutorial completo](../manual/TUTORIAL_INTRO_V0_1.md)
- [Estructura NDJSON de eventos](../specs/NDJSON.md)
