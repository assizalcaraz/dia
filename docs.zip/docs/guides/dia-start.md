# Guía: `dia start`

**Comando**: `dia start`  
**Versión**: v0.1  
**Propósito**: Inicia una nueva sesión de trabajo, captura el baseline del repositorio y genera la bitácora inicial.

---

## Sintaxis

```bash
dia start [--data-root <ruta>] [--repo <ruta>] [--project <nombre>] [--area <area>] [--context <contexto>] [--intent <intención>] [--dod <definición>] [--mode <modo>] [--actor <actor>] [--user-type <tipo>] [--role <rol>] [--client <cliente>]
```

---

## Parámetros

### Parámetros Comunes (todos los comandos)

- `--data-root <ruta>` (opcional): Ruta base del directorio `data/`. Si no se especifica, usa `repo_root/data`.
- `--area <area>` (opcional, default: `it`): Área de trabajo (`it`, `maker`, `study`, `life`).
- `--context <contexto>` (opcional, default: `""`): Contexto adicional del proyecto.
- `--actor <actor>` (opcional, default: `u_local`): Identificador del actor.
- `--user-type <tipo>` (opcional, default: `human`): Tipo de usuario (`human` | `agent`).
- `--role <rol>` (opcional, default: `director`): Rol del actor (`director` | `cronista` | `operador` | `auxiliar`).
- `--client <cliente>` (opcional, default: `cli`): Cliente utilizado (`cli` | `gui` | `api`).

### Parámetros Específicos

- `--repo <ruta>` (opcional): Ruta del repositorio Git. Si no se especifica, usa el directorio actual (`cwd`).
- `--project <nombre>` (opcional): Nombre del proyecto. Si no se especifica, usa el nombre del directorio del repo.
- `--intent <intención>` (opcional): Intención de la sesión (1 frase). Si no se especifica, se solicita interactivamente.
- `--dod <definición>` (opcional): Definición de Hecho (DoD). Si no se especifica, se solicita interactivamente.
- `--mode <modo>` (opcional, default: `it`): Modo de la sesión (`it` | `maker` | `study` | `life`).

---

## Comportamiento

### 1. Validación del Repositorio

- Verifica que el directorio especificado (o actual) sea un repositorio Git válido.
- Si no es un repo Git, muestra error y termina con código de salida 1.

### 2. Confirmación del Nombre del Proyecto

- Si no se especifica `--project`, usa el nombre del directorio del repo.
- Muestra el nombre propuesto y solicita confirmación.
- Si el usuario escribe `no` o `n`, cancela la operación.

### 3. Solicitud Interactiva (si faltan parámetros)

Si no se proporcionan `--intent`, `--dod` o `--mode`, el comando solicita:
- **Intención**: "Intencion (1 frase): "
- **DoD**: "Definicion de hecho (DoD): "
- **Modo**: "Modo [it]: " (Enter acepta el default `it`)

### 4. Captura del Baseline

- Obtiene la rama actual (`git rev-parse --abbrev-ref HEAD`).
- Obtiene el SHA del HEAD (`git rev-parse HEAD`).
  - Si el repo no tiene commits, `start_sha` será `None` y continúa en "modo inicial".
- Obtiene el estado del working tree (`git status --porcelain`).
- Cuenta archivos tracked (`git ls-files`).
- Si el repo está sucio (tiene cambios), genera un diff inicial y lo guarda como artifact.

### 5. Generación de Eventos

Registra dos eventos en `data/index/events.ndjson`:

- **`SessionStarted`**: Evento de inicio de sesión con toda la información de sesión, actor, proyecto y repo.
- **`RepoBaselineCaptured`**: Evento con el estado inicial del repo (status, tracked files, diff si aplica).

### 6. Generación de Bitácora

- Crea o actualiza `data/bitacora/YYYY-MM-DD.md` (archivo único por jornada).
- Agrega sección automática con información de la sesión:
  - ID de sesión (S01, S02, etc.)
  - Timestamp de inicio
  - Intención, DoD, modo
  - Ruta del repo, rama, SHA inicial
  - Estado pendiente de cierre
- Si el archivo no existe, crea la estructura inicial con secciones manuales (1 y 2) y automáticas (3+).

### 7. Generación de `.cursorrules`

- Crea o actualiza `.cursorrules` en el repositorio activo.
- Contiene recordatorio del workflow `/dia` y convención de commits.
- Se regenera cada vez que ejecutas `dia start`.

### 8. Registro en `sessions.ndjson`

- Agrega el evento `SessionStarted` a `data/index/sessions.ndjson` (legacy, mantenido por compatibilidad).

---

## Archivos Generados

### Bitácora de Jornada

**Ubicación**: `data/bitacora/YYYY-MM-DD.md`

**Estructura inicial** (si no existe):

```markdown
# Jornada YYYY-MM-DD

## 1. Intención del día (manual)
- Objetivo principal:
- Definición de Hecho (DoD):
- Restricciones / contexto:

## 2. Notas humanas (manual)
- ideas
- dudas
- decisiones
- observaciones subjetivas relevantes

---

## 3. Registro automático (NO EDITAR)
(append-only, escrito por /dia)

### Sesión S01
- start: 2026-01-18T10:00:00-03:00
- intent: Implementar feature X
- dod: Feature funcionando y tests pasando
- mode: it
- repo: /ruta/al/repo
- branch: main
- start_sha: abc123
- end: (pendiente)
- commits: (pendiente)
- eventos:

#### Eventos
- 2026-01-18T10:00:00-03:00 — SessionStarted
```

### Eventos NDJSON

**Ubicación**: `data/index/events.ndjson`

**Eventos generados**:

1. `SessionStarted`:
```json
{
  "event_id": "evt_...",
  "ts": "2026-01-18T10:00:00-03:00",
  "type": "SessionStarted",
  "session": {
    "day_id": "2026-01-18",
    "session_id": "S01",
    "intent": "Implementar feature X",
    "dod": "Feature funcionando y tests pasando",
    "mode": "it"
  },
  "actor": {...},
  "project": {...},
  "repo": {...},
  "payload": {"cmd": "dia start"}
}
```

2. `RepoBaselineCaptured`:
```json
{
  "event_id": "evt_...",
  "ts": "2026-01-18T10:00:05-03:00",
  "type": "RepoBaselineCaptured",
  "session": {...},
  "payload": {
    "status_porcelain": "",
    "tracked_files": 1284
  },
  "links": [{"kind": "artifact", "ref": "artifacts/S01_repo_diff_start.patch"}]
}
```

### Artifacts

**Si el repo está sucio**:
- `data/artifacts/S01_repo_diff_start.patch`: Diff del estado inicial

**En el repo activo**:
- `.cursorrules`: Recordatorio de workflow para Cursor

---

## Ejemplos de Uso

### Ejemplo 1: Uso Básico (Interactivo)

```bash
cd /ruta/al/repo
dia start --data-root /ruta/al/monorepo/data --area it
```

**Interacción**:
```
Se usara 'mi-proyecto' como nombre del proyecto.
Confirmar? (escriba 'no' para cancelar): 
Intencion (1 frase): Implementar autenticación OAuth2
Definicion de hecho (DoD): Login funcional y tests pasando
Modo [it]: 
Sesion S01 iniciada. Bitacora: /ruta/al/monorepo/data/bitacora/2026-01-18.md
```

### Ejemplo 2: Uso No Interactivo (Todos los Parámetros)

```bash
dia start \
  --data-root /ruta/al/monorepo/data \
  --repo /ruta/al/repo \
  --project mi-proyecto \
  --area it \
  --intent "Implementar autenticación OAuth2" \
  --dod "Login funcional y tests pasando" \
  --mode it
```

### Ejemplo 3: Repo Sin Commits

```bash
cd /ruta/al/repo-nuevo  # Repo recién inicializado
dia start --data-root /ruta/al/monorepo/data --area it
```

**Salida**:
```
Repo sin commits. Continuando en modo inicial.
Sesion S01 iniciada. Bitacora: ...
```

El comando continúa normalmente, pero `start_sha` será `None` en los eventos.

---

## Casos de Uso

### Caso 1: Iniciar Sesión en Repo Existente

**Escenario**: Trabajar en un proyecto existente con historial de commits.

```bash
cd /ruta/al/proyecto-existente
dia start --data-root /ruta/al/monorepo/data --area it
```

**Resultado**: Sesión iniciada con baseline completo (SHA, branch, estado).

### Caso 2: Iniciar Sesión en Repo Nuevo

**Escenario**: Trabajar en un proyecto nuevo sin commits aún.

```bash
cd /ruta/al/proyecto-nuevo
git init
dia start --data-root /ruta/al/monorepo/data --area it
```

**Resultado**: Sesión iniciada en "modo inicial" (sin SHA, pero funcional).

### Caso 3: Múltiples Sesiones en el Mismo Día

**Escenario**: Trabajar en múltiples sesiones durante el día.

```bash
# Sesión 1 (mañana)
dia start --data-root /ruta/data --area it
# ... trabajar ...
dia end --data-root /ruta/data --area it

# Sesión 2 (tarde)
dia start --data-root /ruta/data --area it
# ... trabajar ...
dia end --data-root /ruta/data --area it
```

**Resultado**: Cada sesión se numera secuencialmente (S01, S02, etc.) y se registra en la misma bitácora de jornada.

---

## Integración con Otros Comandos

### Flujo Completo

```bash
# 1. Iniciar sesión
dia start --data-root /ruta/data --area it

# 2. Trabajar normalmente
# ... editar código ...

# 3. Capturar error (si ocurre)
comando_que_falla 2>&1 | dia cap --kind error --title "descripción" --data-root /ruta/data --area it

# 4. Arreglar y linkear fix
dia fix --title "descripción del fix" --data-root /ruta/data --area it

# 5. Checkpoint antes de commit
dia pre-feat --data-root /ruta/data --area it

# 6. Cerrar sesión
dia end --data-root /ruta/data --area it
```

### Dependencias

- **Requiere**: Repositorio Git válido
- **Genera**: Sesión activa que otros comandos pueden usar (`dia pre-feat`, `dia end`, `dia cap`, `dia fix`)
- **Crea**: Bitácora de jornada que `dia close-day` puede leer

---

## Troubleshooting

### Error: "Repo invalido o no es git"

**Causa**: El directorio actual (o especificado con `--repo`) no es un repositorio Git.

**Solución**: 
```bash
cd /ruta/al/repo-git-valido
# o
dia start --repo /ruta/al/repo-git-valido --data-root /ruta/data --area it
```

### Error: "No hay sesion activa para este repo"

**Causa**: Este error aparece en otros comandos (`dia pre-feat`, `dia end`, etc.), no en `dia start`. Indica que no se ejecutó `dia start` previamente.

**Solución**: Ejecutar `dia start` primero.

### Problema: Bitácora no se crea

**Causa**: Permisos insuficientes o ruta de `--data-root` incorrecta.

**Solución**: 
- Verificar permisos del directorio `data/`
- Verificar que `--data-root` apunta al directorio correcto
- Verificar que el directorio existe o puede crearse

### Problema: `.cursorrules` no se genera

**Causa**: Permisos insuficientes en el repositorio.

**Solución**: Verificar permisos de escritura en el directorio del repo.

---

## Notas de Implementación

- El ID de sesión se genera secuencialmente por día: `S01`, `S02`, etc.
- Si hay múltiples sesiones en el mismo día, cada una obtiene el siguiente número.
- El comando es **idempotente** en el sentido de que puedes ejecutarlo múltiples veces, pero cada ejecución crea una nueva sesión.
- La bitácora de jornada es **append-only** en la sección automática (3+). Las secciones 1 y 2 son editables manualmente.

---

## Referencias

- [Tutorial completo](../manual/TUTORIAL_INTRO_V0_1.md)
- [Estructura NDJSON de eventos](../specs/NDJSON.md)
- [Resumen de diseño](../overview/RESUMEN_DISENO_DIA.md)
