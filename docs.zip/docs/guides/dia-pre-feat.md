# Guía: `dia pre-feat`

**Comando**: `dia pre-feat`  
**Versión**: v0.1  
**Propósito**: Sugiere un mensaje de commit con formato correcto, considerando errores activos y tipo de cambios.

---

## Sintaxis

```bash
dia pre-feat [--data-root <ruta>] [--repo <ruta>] [--area <area>] [--context <contexto>] [--actor <actor>] [--user-type <tipo>] [--role <rol>] [--client <cliente>]
```

---

## Parámetros

### Parámetros Comunes

Ver [Guía de `dia start`](dia-start.md#parámetros-comunes-todos-los-comandos) para parámetros comunes (`--data-root`, `--area`, `--context`, `--actor`, `--user-type`, `--role`, `--client`).

### Parámetros Específicos

- `--repo <ruta>` (opcional): Ruta del repositorio Git. Si no se especifica, usa el directorio actual (`cwd`).

---

## Comportamiento

### 1. Verificación de Sesión Activa

- Busca una sesión activa para el repositorio actual (o especificado).
- Si no hay sesión activa, muestra error y termina con código de salida 1.

### 2. Análisis de Cambios

- Obtiene el `start_sha` de la sesión activa.
- Si el repo no tiene commits, analiza cambios en working tree.
- Si el repo tiene commits, analiza cambios entre `start_sha` y `HEAD`.
- Lista archivos modificados.

### 3. Detección de Error Activo

- Busca el último `CaptureCreated` sin `FixLinked` asociado en la sesión actual.
- Si encuentra un error activo:
  - Extrae `error_hash` (primeros 8 caracteres) y `title` del error.
  - Sugiere mensaje de commit tipo `fix:` con referencia al error.
- Si no hay error activo:
  - Analiza el tipo de cambios para sugerir tipo de commit.

### 4. Sugerencia de Tipo de Commit

**Lógica de sugerencia** (sin error activo):

- Si todos los archivos cambiados están en `docs/` → `docs`
- Si hay archivos en `tests/` o con `/tests/` en la ruta → `test`
- Si hay cambios en código → `feat`
- Si no hay cambios → `chore`

### 5. Generación del Comando

**Formato del mensaje**:

- **Con error activo**:
  ```
  🦾 fix: <título del error> [dia] [#sesion Sxx] [#error <hash>]
  ```

- **Sin error activo**:
  ```
  🦾 <tipo>: pre-feat checkpoint [#sesion Sxx]
  ```

**Comando sugerido**:

```bash
git-commit-cursor -m "🦾 <mensaje>"
```

Si `git-commit-cursor` no está en PATH, usa la ruta completa del script.

### 6. Registro de Evento

Registra evento `CommitSuggestionIssued` en `data/index/events.ndjson`:

```json
{
  "event_id": "evt_...",
  "ts": "2026-01-18T11:00:00-03:00",
  "type": "CommitSuggestionIssued",
  "session": {...},
  "payload": {
    "command": "git-commit-cursor -m \"🦾 fix: ...\"",
    "files": ["archivo1.py", "archivo2.py"],
    "error_ref": {
      "error_event_id": "evt_...",
      "error_hash": "..."
    }
  }
}
```

Si hay error activo, incluye `error_ref` en el payload.

### 7. Salida

Imprime el comando sugerido en stdout. El usuario debe copiarlo y ejecutarlo manualmente.

---

## Archivos Generados

### Eventos NDJSON

**Ubicación**: `data/index/events.ndjson`

**Evento generado**: `CommitSuggestionIssued`

---

## Ejemplos de Uso

### Ejemplo 1: Checkpoint Normal (Sin Error Activo)

```bash
# Después de hacer cambios
dia pre-feat --data-root /ruta/data --area it
```

**Salida**:
```bash
git-commit-cursor -m "🦾 feat: pre-feat checkpoint [#sesion S01]"
```

**Archivos cambiados**: `src/auth.py`, `src/models.py`

**Tipo sugerido**: `feat` (hay cambios en código)

### Ejemplo 2: Checkpoint con Error Activo

```bash
# 1. Capturar error
comando_que_falla 2>&1 | dia cap --kind error --title "deploy staging falla" --data-root /ruta/data --area it

# 2. Arreglar el error
# ... editar código ...

# 3. Checkpoint (detecta error activo)
dia pre-feat --data-root /ruta/data --area it
```

**Salida**:
```bash
git-commit-cursor -m "🦾 fix: deploy staging falla [dia] [#sesion S01] [#error a1b2c3d4]"
```

**Comportamiento**: Detecta automáticamente el error activo y sugiere mensaje de `fix:` con referencia.

### Ejemplo 3: Checkpoint de Documentación

```bash
# Cambios solo en docs/
dia pre-feat --data-root /ruta/data --area it
```

**Salida**:
```bash
git-commit-cursor -m "🦾 docs: pre-feat checkpoint [#sesion S01]"
```

**Tipo sugerido**: `docs` (todos los archivos en `docs/`)

### Ejemplo 4: Checkpoint de Tests

```bash
# Cambios en tests/
dia pre-feat --data-root /ruta/data --area it
```

**Salida**:
```bash
git-commit-cursor -m "🦾 test: pre-feat checkpoint [#sesion S01]"
```

**Tipo sugerido**: `test` (hay archivos en `tests/`)

---

## Casos de Uso

### Caso 1: Checkpoint Antes de Commit Importante

**Escenario**: Hacer un checkpoint antes de un commit significativo.

```bash
# Trabajar
# ... editar código ...

# Checkpoint
dia pre-feat --data-root /ruta/data --area it
# Copiar y ejecutar comando sugerido
```

**Resultado**: Commit con formato correcto y referencia a sesión.

### Caso 2: Fix de Error Capturado

**Escenario**: Arreglar un error que fue capturado previamente.

```bash
# 1. Error ocurre
comando_que_falla 2>&1 | dia cap --kind error --title "error de conexión" --data-root /ruta/data --area it

# 2. Arreglar
# ... editar código ...

# 3. Checkpoint (sugiere fix automáticamente)
dia pre-feat --data-root /ruta/data --area it
# Salida: git-commit-cursor -m "🦾 fix: error de conexión [dia] [#sesion S01] [#error a1b2c3d4]"

# 4. Ejecutar commit
git-commit-cursor -m "🦾 fix: error de conexión [dia] [#sesion S01] [#error a1b2c3d4]"

# 5. Linkear fix (opcional, si no se hizo antes)
dia fix --title "corregir timeout de conexión" --data-root /ruta/data --area it
```

**Resultado**: Commit vinculado al error capturado, trazabilidad completa.

### Caso 3: Múltiples Checkpoints en una Sesión

**Escenario**: Hacer múltiples checkpoints durante una sesión.

```bash
# Checkpoint 1
dia pre-feat --data-root /ruta/data --area it
# Salida: git-commit-cursor -m "🦾 feat: pre-feat checkpoint [#sesion S01]"

# ... más trabajo ...

# Checkpoint 2
dia pre-feat --data-root /ruta/data --area it
# Salida: git-commit-cursor -m "🦾 feat: pre-feat checkpoint [#sesion S01]"
```

**Resultado**: Cada checkpoint genera un evento `CommitSuggestionIssued` independiente.

---

## Integración con Otros Comandos

### Flujo con Captura de Errores

```bash
# 1. Iniciar sesión
dia start --data-root /ruta/data --area it

# 2. Trabajar
# ... editar código ...

# 3. Error ocurre → capturar
comando_que_falla 2>&1 | dia cap --kind error --title "descripción" --data-root /ruta/data --area it

# 4. Arreglar error
# ... editar código ...

# 5. Checkpoint (detecta error automáticamente)
dia pre-feat --data-root /ruta/data --area it
# → Sugiere mensaje con referencia a error

# 6. Ejecutar commit sugerido
git-commit-cursor -m "🦾 fix: ..."

# 7. Linkear fix (opcional)
dia fix --title "descripción del fix" --data-root /ruta/data --area it

# 8. Cerrar sesión
dia end --data-root /ruta/data --area it
```

### Dependencias

- **Requiere**: Sesión activa (`dia start` ejecutado previamente)
- **Usa**: Información de sesión activa (start_sha, session_id)
- **Integra con**: `dia cap` y `dia fix` para trazabilidad de errores
- **Genera**: Evento que `dia end` puede usar para análisis

---

## Troubleshooting

### Error: "No hay sesion activa para este repo"

**Causa**: No se ejecutó `dia start` previamente o la sesión fue cerrada con `dia end`.

**Solución**: 
```bash
dia start --data-root /ruta/data --area it
```

### Problema: No detecta error activo

**Causa**: 
- El error no fue capturado con `dia cap`
- El error ya fue linkeado con `dia fix`
- El error es de otra sesión

**Solución**: 
- Verificar que ejecutaste `dia cap` antes
- Verificar que no ejecutaste `dia fix` para ese error
- Verificar que estás en la misma sesión

### Problema: Tipo de commit incorrecto

**Causa**: La lógica de detección de tipo puede no ser perfecta.

**Solución**: 
- El comando solo sugiere, puedes modificar el mensaje antes de ejecutarlo
- Ejemplo: Si sugiere `feat` pero es `refactor`, modifica el mensaje

---

## Notas de Implementación

- El comando **no ejecuta** el commit, solo lo sugiere. El usuario debe copiar y ejecutar manualmente.
- La detección de error activo busca el **último** `CaptureCreated` sin `FixLinked` en la sesión actual.
- El formato del mensaje incluye `[dia]` solo cuando hay error activo (legacy, mantenido por compatibilidad).
- El comando usa `git-commit-cursor` para commits de Cursor/IA (autoría identificable).

---

## Referencias

- [Guía de `dia start`](dia-start.md)
- [Guía de `dia cap`](dia-cap.md)
- [Guía de `dia fix`](dia-fix.md)
- [Tutorial completo](../manual/TUTORIAL_INTRO_V0_1.md)
