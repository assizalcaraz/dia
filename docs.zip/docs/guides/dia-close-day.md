# Guía: `dia close-day`

**Comando**: `dia close-day`  
**Versión**: v0.1  
**Propósito**: Cierra la jornada generando resúmenes automáticos, análisis comparativo vs objetivo y síntesis del día.

---

## Sintaxis

```bash
dia close-day [--data-root <ruta>] [--area <area>] [--context <contexto>] [--actor <actor>] [--user-type <tipo>] [--role <rol>] [--client <cliente>]
```

---

## Parámetros

### Parámetros Comunes

Ver [Guía de `dia start`](dia-start.md#parámetros-comunes-todos-los-comandos) para parámetros comunes (`--data-root`, `--area`, `--context`, `--actor`, `--user-type`, `--role`, `--client`).

**Nota**: Este comando no requiere `--repo` porque opera a nivel de jornada, no de sesión.

---

## Comportamiento

### 1. Lectura de Eventos del Día

- Lee todos los eventos de `data/index/events.ndjson`.
- Filtra eventos del día actual (`day_id` = fecha actual).
- Si no hay eventos, muestra error y termina con código de salida 1.

### 2. Lectura de Bitácora de Jornada

- Lee `data/bitacora/YYYY-MM-DD.md` (bitácora del día actual).
- Si no existe, muestra error y termina con código de salida 1.

### 3. Análisis de Sesiones

- Identifica todas las sesiones del día (eventos `SessionStarted` y `SessionEnded`).
- Cuenta sesiones iniciadas vs cerradas.
- Extrae información de cada sesión.

### 4. Extracción de Objetivo del Día

- Intenta extraer el objetivo principal de la sección 1 de la bitácora (manual).
- Busca línea con "Objetivo principal:" y extrae el siguiente contenido.
- Si no encuentra, usa "No especificado".

### 5. Extracción de Plan Esperado

- Intenta extraer la Definición de Hecho (DoD) de la sección 1 de la bitácora.
- Busca línea con "Definición de Hecho (DoD):" y extrae el siguiente contenido.
- Si no encuentra, usa "No especificado".

### 6. Generación de Resumen del Día

Genera resumen con:

- **Qué se intentó**: Número de sesiones iniciadas
- **Qué se logró realmente**: Sesiones cerradas, eventos registrados
- **Qué no se logró**: Sesiones sin cerrar (si aplica)
- **Desvíos detectados**: Lista de desvíos (sesiones abiertas, etc.)

### 7. Actualización de Bitácora

- Agrega sección 5 "Resumen del día (generado)" a la bitácora de jornada.
- El resumen se agrega en la sección automática (append-only).

### 8. Generación de Análisis vs Objetivo

Si hay objetivo especificado (no "No especificado"):

- Crea `data/analysis/YYYY-MM-DD_vs_objetivo.md`.
- Compara objetivo declarado vs resultado real.
- Identifica brechas.
- Calcula impacto.
- Sugiere ajustes.

### 9. Registro de Evento

Registra evento `DailySummaryGenerated` en:

- `data/index/events.ndjson`
- `data/index/daily_summaries.ndjson` (índice de resúmenes)

---

## Archivos Generados

### Bitácora de Jornada (Actualizada)

**Ubicación**: `data/bitacora/YYYY-MM-DD.md`

**Nueva sección agregada**:

```markdown
## 5. Resumen del día (generado)

- Qué se intentó: 2 sesiones iniciadas
- Qué se logró realmente: 2 sesiones cerradas, 15 eventos registrados
- Qué no se logró y por qué: Todas las sesiones cerradas
- Desvíos detectados:
- Sin desvíos detectados
```

### Análisis vs Objetivo

**Ubicación**: `data/analysis/YYYY-MM-DD_vs_objetivo.md`

**Contenido** (si hay objetivo):

```markdown
# Análisis 2026-01-18 vs Objetivo

## Objetivo declarado
Implementar autenticación OAuth2

## Plan esperado
Login funcional, tests pasando, docs actualizados

## Resultado real
2 sesiones cerradas, 15 eventos registrados

## Brechas
- Sin brechas significativas

## Impacto
2/2 sesiones completadas

## Ajustes sugeridos
- Sin ajustes sugeridos
```

### Eventos NDJSON

**Ubicación**: `data/index/events.ndjson` y `data/index/daily_summaries.ndjson`

**Evento generado**: `DailySummaryGenerated`

```json
{
  "event_id": "evt_...",
  "ts": "2026-01-18T18:00:00-03:00",
  "type": "DailySummaryGenerated",
  "session": {
    "day_id": "2026-01-18",
    "session_id": null
  },
  "payload": {
    "objective": "Implementar autenticación OAuth2",
    "sessions": 2,
    "closed_sessions": 2,
    "total_events": 15
  }
}
```

---

## Ejemplos de Uso

### Ejemplo 1: Cierre de Jornada Normal

```bash
# Al final del día, después de cerrar todas las sesiones
dia close-day --data-root /ruta/data --area it
```

**Salida**:
```
Jornada 2026-01-18 cerrada. Resumen agregado a /ruta/data/bitacora/2026-01-18.md
Análisis generado: /ruta/data/analysis/2026-01-18_vs_objetivo.md
```

### Ejemplo 2: Cierre con Sesiones Sin Cerrar

```bash
dia close-day --data-root /ruta/data --area it
```

**Resumen generado**:
```markdown
- Qué se intentó: 3 sesiones iniciadas
- Qué se logró realmente: 2 sesiones cerradas, 12 eventos registrados
- Qué no se logró y por qué: 1 sesión sin cerrar
- Desvíos detectados:
- 1 sesión quedó abierta
```

### Ejemplo 3: Cierre Sin Objetivo Especificado

```bash
dia close-day --data-root /ruta/data --area it
```

**Comportamiento**:
- Genera resumen del día
- No genera análisis vs objetivo (objetivo = "No especificado")
- Muestra mensaje: "Jornada 2026-01-18 cerrada. Resumen agregado a ..."

---

## Casos de Uso

### Caso 1: Cierre de Jornada Completa

**Escenario**: Terminar el día después de trabajar en múltiples sesiones.

```bash
# Sesión 1 (mañana)
dia start --data-root /ruta/data --area it
# ... trabajar ...
dia end --data-root /ruta/data --area it

# Sesión 2 (tarde)
dia start --data-root /ruta/data --area it
# ... trabajar ...
dia end --data-root /ruta/data --area it

# Cerrar jornada (al final del día)
dia close-day --data-root /ruta/data --area it
```

**Resultado**: 
- Resumen consolidado del día
- Análisis vs objetivo (si hay objetivo)
- Evento `DailySummaryGenerated` registrado

### Caso 2: Jornada con Objetivo Definido

**Escenario**: Trabajar con objetivo claro definido en la bitácora.

```bash
# 1. Iniciar sesión
dia start --data-root /ruta/data --area it

# 2. Editar bitácora y definir objetivo
# Editar data/bitacora/2026-01-18.md, sección 1:
# - Objetivo principal: Implementar autenticación OAuth2
# - Definición de Hecho (DoD): Login funcional, tests pasando

# 3. Trabajar
# ... editar código ...

# 4. Cerrar sesión
dia end --data-root /ruta/data --area it

# 5. Cerrar jornada
dia close-day --data-root /ruta/data --area it
```

**Resultado**: 
- Resumen del día
- Análisis comparativo vs objetivo
- Identificación de brechas y ajustes sugeridos

### Caso 3: Jornada con Sesiones Abiertas

**Escenario**: Olvidar cerrar una sesión antes de cerrar la jornada.

```bash
# Sesión 1
dia start --data-root /ruta/data --area it
dia end --data-root /ruta/data --area it

# Sesión 2 (olvidar cerrar)
dia start --data-root /ruta/data --area it
# ... trabajar pero no cerrar ...

# Cerrar jornada
dia close-day --data-root /ruta/data --area it
```

**Resultado**: 
- Resumen indica sesiones sin cerrar
- Desvíos detectados incluyen sesiones abiertas
- Ajustes sugeridos: "Cerrar sesiones pendientes antes de continuar"

---

## Integración con Otros Comandos

### Flujo Completo del Día

```bash
# Inicio de jornada
dia start --data-root /ruta/data --area it

# ... trabajar en múltiples sesiones ...
dia end --data-root /ruta/data --area it
dia start --data-root /ruta/data --area it
dia end --data-root /ruta/data --area it

# Cierre de jornada (una sola vez al final del día)
dia close-day --data-root /ruta/data --area it
```

### Dependencias

- **Requiere**: 
  - Eventos del día en `events.ndjson` (generados por `dia start`, `dia end`, etc.)
  - Bitácora de jornada existente (creada por `dia start`)
- **Usa**: 
  - Eventos del día para análisis
  - Sección 1 de bitácora para objetivo y plan
- **Genera**: 
  - Resumen en bitácora (sección 5)
  - Análisis vs objetivo (si hay objetivo)
  - Evento `DailySummaryGenerated`

---

## Troubleshooting

### Error: "No hay eventos registrados para YYYY-MM-DD"

**Causa**: No se ejecutó `dia start` ese día o no hay eventos.

**Solución**: 
```bash
dia start --data-root /ruta/data --area it
```

### Error: "No existe bitácora para YYYY-MM-DD"

**Causa**: No se ejecutó `dia start` ese día o la bitácora no se creó.

**Solución**: 
```bash
dia start --data-root /ruta/data --area it
```

### Problema: Análisis vs objetivo dice "No especificado"

**Causa**: No se completó la sección 1 de la bitácora (objetivo principal).

**Solución**: 
- Editar `data/bitacora/YYYY-MM-DD.md`
- Completar sección 1 antes de ejecutar `dia close-day`

### Problema: Resumen no aparece en bitácora

**Causa**: Permisos insuficientes o estructura de bitácora incorrecta.

**Solución**: 
- Verificar permisos del archivo de bitácora
- Verificar que la bitácora tiene la estructura correcta (sección 3 existe)

---

## Notas de Implementación

- El comando **no requiere sesión activa**. Opera a nivel de jornada, no de sesión.
- El análisis vs objetivo solo se genera si hay objetivo especificado (no "No especificado").
- El resumen se agrega en la sección automática (append-only) de la bitácora.
- El comando puede ejecutarse múltiples veces en el mismo día, pero cada ejecución genera un nuevo resumen (append).

---

## Referencias

- [Guía de `dia start`](dia-start.md)
- [Guía de `dia end`](dia-end.md)
- [Tutorial completo](../manual/TUTORIAL_INTRO_V0_1.md)
- [Estructura NDJSON de eventos](../specs/NDJSON.md)
