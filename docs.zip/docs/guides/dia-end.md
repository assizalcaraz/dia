# Guía: `dia end`

**Comando**: `dia end`  
**Versión**: v0.1  
**Propósito**: Cierra una sesión activa, calcula el diff de la sesión, genera reportes de cierre y limpieza, y actualiza la bitácora.

---

## Sintaxis

```bash
dia end [--data-root <ruta>] [--repo <ruta>] [--area <area>] [--context <contexto>] [--actor <actor>] [--user-type <tipo>] [--role <rol>] [--client <cliente>]
```

---

## Parámetros

### Parámetros Comunes

Ver [Guía de `dia start`](dia-start.md#parámetros-comunes-todos-los-comandos) para parámetros comunes (`--data-root`, `--area`, `--context`, `--actor`, `--user-type`, `--role`, `--client`).

### Parámetros Específicos

- `--repo <ruta>` (opcional): Ruta del repositorio Git. Si no se especifica, usa el directorio actual (`cwd`).

---

## Comportamiento

### 1. Verificación de Sesión Activa

- Busca una sesión activa para el repositorio actual (o especificado).
- Si no hay sesión activa, muestra error y termina con código de salida 1.

### 2. Cálculo del Diff de la Sesión

- Obtiene el `start_sha` de la sesión activa.
- Obtiene el `end_sha` (HEAD actual).
- Si el repo no tiene commits:
  - Analiza cambios en working tree.
  - No hay commits para listar.
- Si el repo tiene commits:
  - Calcula diff entre `start_sha` y `end_sha`.
  - Lista commits con `git log --oneline <start_sha>..<end_sha>`.
  - Cuenta número de commits.

### 3. Detección de Archivos Sospechosos

Analiza archivos modificados y detecta:

- **Archivos en `docs/scratch/`**: Sugiere mover a `docs/_scratch/`
- **Tests fuera de `tests/`**: Archivos `*_test.py` que no están en `tests/` o con `/tests/` en la ruta

### 4. Generación de Tareas de Limpieza

Crea lista de tareas basada en archivos sospechosos:

- Si encuentra `docs/scratch/`: "Mover {archivo} -> docs/_scratch/ (evitar drift)"
- Si encuentra `*_test.py` fuera de tests: "Mover {archivo} a tests/test_<feature>.py"
- Si no hay tareas específicas: "Revisar cambios y consolidar docs si aplica"

### 5. Generación de Eventos

Registra tres eventos en `data/index/events.ndjson`:

- **`RepoDiffComputed`**: Diff de la sesión con estadísticas (archivos cambiados, commits).
- **`CleanupTaskGenerated`**: Lista de tareas de limpieza sugeridas.
- **`SessionEnded`**: Evento de cierre de sesión.

### 6. Actualización de Bitácora

- Actualiza `data/bitacora/YYYY-MM-DD.md` (bitácora de jornada).
- Agrega información de cierre en la sección automática:
  - Timestamp de cierre
  - `end_sha`
  - Número de commits
  - Archivos tocados

### 7. Generación de Archivos Legacy

Genera archivos de cierre y limpieza (mantenidos por compatibilidad):

- **`data/bitacora/YYYY-MM-DD/CIERRE_Sxx.md`**: Resumen de sesión con alertas y próxima acción.
- **`data/bitacora/YYYY-MM-DD/LIMPIEZA_Sxx.md`**: Lista de tareas de limpieza concretas.

### 8. Guardado de Artifacts

- Guarda diff de la sesión en `data/artifacts/Sxx_repo_diff_end.patch`.
- Vincula el artifact en el evento `RepoDiffComputed`.

### 9. Registro en `sessions.ndjson`

- Agrega el evento `SessionEnded` a `data/index/sessions.ndjson` (legacy, mantenido por compatibilidad).

---

## Archivos Generados

### Bitácora de Jornada (Actualizada)

**Ubicación**: `data/bitacora/YYYY-MM-DD.md`

**Actualización en sección automática**:

```markdown
### Sesión S01
- start: 2026-01-18T10:00:00-03:00
- intent: Implementar feature X
- dod: Feature funcionando y tests pasando
- mode: it
- repo: /ruta/al/repo
- branch: main
- start_sha: abc123
- end: 2026-01-18T14:30:00-03:00
- commits: 3
- archivos_tocados: 12
- 2026-01-18T14:30:00-03:00 — SessionEnded
```

### Archivos Legacy

**Ubicación**: `data/bitacora/YYYY-MM-DD/CIERRE_Sxx.md`

**Contenido**:

```markdown
# CIERRE 2026-01-18 S01

## Resumen

3 commits, 12 archivos tocados.

## Alertas

- Sin alertas

## Proxima accion

- Revisar limpieza
```

**Ubicación**: `data/bitacora/YYYY-MM-DD/LIMPIEZA_Sxx.md`

**Contenido**:

```markdown
# LIMPIEZA 2026-01-18 S01

## Tareas

- Mover docs/scratch/notas.md -> docs/_scratch/ (evitar drift)
- Mover 15_test.py a tests/test_<feature>.py
```

### Eventos NDJSON

**Ubicación**: `data/index/events.ndjson`

**Eventos generados**:

1. `RepoDiffComputed`:
```json
{
  "event_id": "evt_...",
  "ts": "2026-01-18T14:30:00-03:00",
  "type": "RepoDiffComputed",
  "session": {
    "day_id": "2026-01-18",
    "session_id": "S01",
    "result": "closed"
  },
  "payload": {
    "files_changed": 12,
    "commits": 3
  },
  "links": [{"kind": "artifact", "ref": "artifacts/S01_repo_diff_end.patch"}]
}
```

2. `CleanupTaskGenerated`:
```json
{
  "event_id": "evt_...",
  "type": "CleanupTaskGenerated",
  "payload": {
    "tasks": [
      "Mover docs/scratch/notas.md -> docs/_scratch/ (evitar drift)"
    ]
  }
}
```

3. `SessionEnded`:
```json
{
  "event_id": "evt_...",
  "type": "SessionEnded",
  "session": {
    "day_id": "2026-01-18",
    "session_id": "S01",
    "result": "closed"
  },
  "payload": {
    "cmd": "dia end",
    "duration_min": null
  }
}
```

### Artifacts

- `data/artifacts/S01_repo_diff_end.patch`: Diff completo de la sesión

---

## Ejemplos de Uso

### Ejemplo 1: Cierre Normal

```bash
# Después de trabajar
dia end --data-root /ruta/data --area it
```

**Salida**:
```
Sesion S01 cerrada. Bitacora jornada: /ruta/data/bitacora/2026-01-18.md
```

**Archivos generados**:
- Bitácora actualizada
- `CIERRE_S01.md`
- `LIMPIEZA_S01.md`
- `S01_repo_diff_end.patch`

### Ejemplo 2: Cierre con Archivos Sospechosos

```bash
dia end --data-root /ruta/data --area it
```

**Archivos detectados**:
- `docs/scratch/notas.md`
- `15_test.py` (fuera de `tests/`)

**Tareas generadas**:
- "Mover docs/scratch/notas.md -> docs/_scratch/ (evitar drift)"
- "Mover 15_test.py a tests/test_<feature>.py"

### Ejemplo 3: Cierre en Repo Sin Commits

```bash
# Repo nuevo, sin commits aún
dia end --data-root /ruta/data --area it
```

**Comportamiento**:
- Analiza cambios en working tree
- `commits: 0`
- Genera diff de working tree

---

## Casos de Uso

### Caso 1: Cierre de Sesión Completa

**Escenario**: Terminar una sesión de trabajo.

```bash
# 1. Iniciar sesión
dia start --data-root /ruta/data --area it

# 2. Trabajar
# ... editar código, hacer commits ...

# 3. Cerrar sesión
dia end --data-root /ruta/data --area it
```

**Resultado**: Sesión cerrada, bitácora actualizada, reportes generados.

### Caso 2: Múltiples Sesiones en un Día

**Escenario**: Trabajar en múltiples sesiones durante el día.

```bash
# Sesión 1
dia start --data-root /ruta/data --area it
# ... trabajar ...
dia end --data-root /ruta/data --area it

# Sesión 2
dia start --data-root /ruta/data --area it
# ... trabajar ...
dia end --data-root /ruta/data --area it
```

**Resultado**: Cada sesión se cierra independientemente, todas aparecen en la misma bitácora de jornada.

### Caso 3: Cierre con Limpieza Pendiente

**Escenario**: Sesión con archivos que requieren limpieza.

```bash
dia end --data-root /ruta/data --area it
```

**Resultado**: 
- `LIMPIEZA_S01.md` con tareas concretas
- Evento `CleanupTaskGenerated` registrado
- Tareas aparecen en el cierre para revisión

---

## Integración con Otros Comandos

### Flujo Completo

```bash
# 1. Iniciar sesión
dia start --data-root /ruta/data --area it

# 2. Trabajar
# ... editar código ...

# 3. Checkpoint (opcional)
dia pre-feat --data-root /ruta/data --area it

# 4. Cerrar sesión
dia end --data-root /ruta/data --area it

# 5. Cerrar jornada (al final del día)
dia close-day --data-root /ruta/data --area it
```

### Dependencias

- **Requiere**: Sesión activa (`dia start` ejecutado previamente)
- **Usa**: Información de sesión activa (start_sha, session_id, day_id)
- **Genera**: Datos que `dia close-day` puede usar para análisis
- **Cierra**: Sesión activa (no se puede usar `dia pre-feat` o `dia cap` después sin iniciar nueva sesión)

---

## Troubleshooting

### Error: "No hay sesion activa para este repo"

**Causa**: No se ejecutó `dia start` previamente o la sesión ya fue cerrada.

**Solución**: 
```bash
dia start --data-root /ruta/data --area it
```

### Problema: Diff no se genera

**Causa**: 
- Repo sin commits y sin cambios en working tree
- Permisos insuficientes

**Solución**: 
- Verificar que hay cambios o commits
- Verificar permisos del directorio `data/artifacts/`

### Problema: Archivos legacy no se generan

**Causa**: Permisos insuficientes en `data/bitacora/YYYY-MM-DD/`.

**Solución**: Verificar permisos del directorio.

---

## Notas de Implementación

- El comando **cierra** la sesión activa. Después de ejecutar `dia end`, no puedes usar `dia pre-feat`, `dia cap` o `dia fix` sin iniciar una nueva sesión.
- La detección de archivos sospechosos usa reglas de `data/rules.json` (o defaults).
- Los archivos legacy (`CIERRE_Sxx.md`, `LIMPIEZA_Sxx.md`) se mantienen por compatibilidad, pero el formato principal es la bitácora de jornada.
- El diff se guarda como artifact y se vincula en el evento `RepoDiffComputed`.

---

## Referencias

- [Guía de `dia start`](dia-start.md)
- [Guía de `dia close-day`](dia-close-day.md)
- [Tutorial completo](../manual/TUTORIAL_INTRO_V0_1.md)
- [Estructura NDJSON de eventos](../specs/NDJSON.md)
